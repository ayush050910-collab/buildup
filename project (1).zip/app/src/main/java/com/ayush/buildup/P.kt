package com.ayush.buildup
import android.content.Context
import android.content.SharedPreferences
import java.text.SimpleDateFormat
import java.util.*

object P {
    fun sp(c: Context): SharedPreferences = c.getSharedPreferences("bu", 0)
    fun running(c: Context) = sp(c).getLong("end", 0) > System.currentTimeMillis()
    fun day(off: Int = 0): String {
        val cal = Calendar.getInstance(); cal.add(Calendar.DAY_OF_YEAR, off)
        return SimpleDateFormat("yyyyMMdd", Locale.US).format(cal.time)
    }
    fun week(c: Context): IntArray {
        val cal = Calendar.getInstance(); cal.firstDayOfWeek = Calendar.MONDAY; cal.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY)
        val f = SimpleDateFormat("yyyyMMdd", Locale.US); val s = sp(c)
        return IntArray(7) { val k = "m" + f.format(cal.time); cal.add(Calendar.DAY_OF_YEAR, 1); s.getInt(k, 0) }
    }
    fun todayIdx() = (Calendar.getInstance().get(Calendar.DAY_OF_WEEK) + 5) % 7
    fun roll(c: Context) {
        val s = sp(c); val e = s.edit()
        if (s.getString("day", "") != day()) e.putString("day", day()).putInt("todayMin", 0)
        val l = s.getString("last", "")
        if (l != day() && l != day(-1)) e.putInt("streak", 0)
        e.apply()
    }
    fun complete(c: Context) {
        roll(c); val s = sp(c); val e = s.edit()
        if (s.getString("last", "") != day()) { e.putInt("streak", s.getInt("streak", 0) + 1); e.putString("last", day()) }
        val d = s.getInt("dur", 0)
        e.putInt("todayMin", s.getInt("todayMin", 0) + d).putInt("m" + day(), s.getInt("m" + day(), 0) + d)
            .putInt("totalMin", s.getInt("totalMin", 0) + d).putLong("end", 0).apply()
    }
}
