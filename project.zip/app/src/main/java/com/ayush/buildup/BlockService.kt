package com.ayush.buildup
import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast

class BlockService : AccessibilityService() {
    private val bad = listOf("porn", "nude", "xxx", "xnxx", "xvideos", "sex video", "sexy video")
    private val browsers = setOf("com.android.chrome", "org.mozilla.firefox", "com.brave.browser", "com.microsoft.emmx",
        "com.opera.browser", "com.sec.android.app.sbrowser", "com.android.browser", "com.heytap.browser",
        "com.UCMobile.intl", "com.duckduckgo.mobile.android", "com.mi.globalbrowser")
    private val guarded = setOf("com.android.settings", "com.google.android.packageinstaller", "com.android.packageinstaller",
        "com.google.android.permissioncontroller", "com.samsung.android.packageinstaller", "com.miui.packageinstaller")

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName) return
        val sp = P.sp(this)
        if (P.running(this)) {
            val apps = sp.getStringSet("apps", emptySet()) ?: emptySet()
            if (pkg in guarded || pkg in apps) { home(); return }
        }
        if (pkg == "com.android.vending") {
            val labels = sp.getStringSet("labels", emptySet()) ?: emptySet()
            if (labels.isEmpty()) return
            val sb = StringBuilder(); collect(rootInActiveWindow, sb, 0)
            if (labels.any { sb.contains(it, true) }) home()
        } else if (pkg in browsers && sp.getBoolean("web", true) && P.running(this)) {
            if (hasBad(rootInActiveWindow, 0)) home()
        }
    }
    private fun collect(n: AccessibilityNodeInfo?, out: StringBuilder, d: Int) {
        if (n == null || d > 25) return
        n.text?.let { out.append(it).append('\n') }
        n.contentDescription?.let { out.append(it).append('\n') }
        for (i in 0 until n.childCount) collect(n.getChild(i), out, d + 1)
    }
    private fun hasBad(n: AccessibilityNodeInfo?, d: Int): Boolean {
        if (n == null || d > 25) return false
        if (n.isEditable) {
            val t = n.text?.toString()?.lowercase() ?: ""
            if (bad.any { t.contains(it) }) return true
        }
        for (i in 0 until n.childCount) if (hasBad(n.getChild(i), d + 1)) return true
        return false
    }
    private fun home() {
        performGlobalAction(GLOBAL_ACTION_HOME)
        Toast.makeText(this, "Blocked by Build Up", Toast.LENGTH_SHORT).show()
    }
    override fun onInterrupt() {}
}
