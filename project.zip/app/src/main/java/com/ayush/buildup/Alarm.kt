package com.ayush.buildup
import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.*
import android.view.Gravity
import android.view.WindowManager
import android.widget.*

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val rc = i.getIntExtra("rc", -1); val id = rc / 10; val day = rc % 10
        if (rc == -2) { try { c.startForegroundService(Intent(c, AlarmService::class.java).putExtra("sid", 0)) } catch (e: Exception) {}; return }
        val list = Sched.load(c); val s = list.find { it.id == id }
        if (s == null) { Sched.scheduleAll(c); return }
        try { c.startForegroundService(Intent(c, AlarmService::class.java).putExtra("sid", id)) }
        catch (e: Exception) {
            val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val ch = NotificationChannel("alarm", "Schedule alarm", NotificationManager.IMPORTANCE_HIGH)
            ch.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM), AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build())
            nm.createNotificationChannel(ch)
            nm.notify(rc, Notification.Builder(c, "alarm").setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle(s.name).setContentText("Schedule shuru ho gaya").setAutoCancel(true)
                .setContentIntent(PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)).build())
        }
        if (s.repeat) Sched.scheduleAll(c)
        else {
            val left = s.days - day
            val nl = list.map {
                if (it.id != id) it
                else if (left.isNotEmpty()) Sc(it.id, it.name, left, it.sh, it.sm, it.eh, it.em, it.alarm, it.repeat, it.breaks)
                else Sc(it.id, it.name, it.days, it.sh, it.sm, it.eh, it.em, false, it.repeat, it.breaks)
            }
            Sched.save(c, nl)
        }
    }
}

class AlarmService : Service() {
    private var rt: Ringtone? = null
    private var vb: Vibrator? = null
    private val h = Handler(Looper.getMainLooper())
    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, sid: Int): Int {
        if (i?.action == "STOP") { end(); return START_NOT_STICKY }
        val id = i?.getIntExtra("sid", 0) ?: 0
        val s = Sched.load(this).find { it.id == id }
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("ring", "Schedule alarm", NotificationManager.IMPORTANCE_HIGH).apply { setSound(null, null) })
        val fl = PendingIntent.FLAG_IMMUTABLE
        val full = PendingIntent.getActivity(this, 1, Intent(this, AlarmActivity::class.java).putExtra("sid", id).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), fl)
        val exit = PendingIntent.getService(this, 2, Intent(this, AlarmService::class.java).setAction("STOP"), fl)
        val go = PendingIntent.getActivity(this, 3, Intent(this, MainActivity::class.java).putExtra("focus_sid", id)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP), fl)
        val n = Notification.Builder(this, "ring").setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(s?.name ?: "Schedule").setContentText("Schedule shuru ho gaya")
            .setCategory(Notification.CATEGORY_ALARM).setOngoing(true).setFullScreenIntent(full, true).setContentIntent(full)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Exit", exit)
            .addAction(android.R.drawable.ic_media_play, "Start focusing", go).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(77, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK) else startForeground(77, n)
        try {
            rt?.stop()
            rt = RingtoneManager.getRingtone(this, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))
            rt?.audioAttributes = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
            if (Build.VERSION.SDK_INT >= 28) rt?.isLooping = true
            rt?.play()
            vb = getSystemService(VIBRATOR_SERVICE) as Vibrator
            vb?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 600, 500), 0))
        } catch (e: Exception) {}
        h.removeCallbacksAndMessages(null); h.postDelayed({ end() }, 60000)
        return START_NOT_STICKY
    }
    private fun end() { rt?.stop(); vb?.cancel(); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf() }
    override fun onDestroy() { rt?.stop(); vb?.cancel(); h.removeCallbacksAndMessages(null); super.onDestroy() }
}

class AlarmActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 27) { setShowWhenLocked(true); setTurnScreenOn(true) }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val id = intent.getIntExtra("sid", 0); val s = Sched.load(this).find { it.id == id }
        val d = resources.displayMetrics.density
        fun tv(t: String, sz: Float, c: Int = Color.WHITE) = TextView(this).apply { text = t; textSize = sz; setTextColor(c); gravity = Gravity.CENTER }
        fun btn(t: String, bg: Int, fg: Int, f: () -> Unit) = Button(this).apply {
            text = t; isAllCaps = false; setTextColor(fg)
            background = GradientDrawable().apply { setColor(bg); cornerRadius = 40 * d }
            setOnClickListener { f() }
            layoutParams = LinearLayout.LayoutParams(-1, (56 * d).toInt()).apply { topMargin = (14 * d).toInt() }
        }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setBackgroundColor(Color.parseColor("#18141A"))
            setPadding((28 * d).toInt(), 0, (28 * d).toInt(), 0)
            addView(tv("⏰", 56f)); addView(tv(s?.name ?: "Schedule", 30f)); addView(tv("Focus ka time ho gaya", 16f, Color.LTGRAY))
            addView(btn("Start focusing", Color.parseColor("#FF6B81"), Color.BLACK) {
                startActivity(Intent(this@AlarmActivity, MainActivity::class.java).putExtra("focus_sid", id)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP))
                finish()
            })
            addView(btn("Exit", Color.parseColor("#241E26"), Color.WHITE) { stopService(Intent(this@AlarmActivity, AlarmService::class.java)); finish() })
        })
    }
}
