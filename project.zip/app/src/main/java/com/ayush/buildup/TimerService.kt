package com.ayush.buildup
import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.*

class TimerService : Service() {
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            val left = P.sp(this@TimerService).getLong("end", 0) - System.currentTimeMillis()
            if (left <= 0) { finish(); return }
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(1, notif(left))
            h.postDelayed(this, 1000)
        }
    }
    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("f", "Focus", NotificationManager.IMPORTANCE_LOW))
        val left = P.sp(this).getLong("end", 0) - System.currentTimeMillis()
        val n = notif(if (left > 0) left else 0)
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(1, n)
        h.removeCallbacks(tick); h.post(tick)
        return START_STICKY
    }
    private fun notif(left: Long): Notification {
        val sp = P.sp(this); val total = sp.getInt("dur", 1) * 60; val l = (left / 1000).toInt()
        val n = sp.getStringSet("apps", emptySet())?.size ?: 0
        return Notification.Builder(this, "f").setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Focus time left")
            .setContentText("%02d:%02d - %d apps blocked".format(l / 60, l % 60, n))
            .setProgress(total, total - l, false).setOngoing(true).setOnlyAlertOnce(true)
            .setContentIntent(PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE))
            .build()
    }
    private fun finish() {
        P.complete(this)
        stopForeground(STOP_FOREGROUND_REMOVE)
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(2, Notification.Builder(this, "f").setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Well done, Ayush!").setContentText("Session complete. Apps unblocked.").build())
        stopSelf()
    }
    override fun onDestroy() { h.removeCallbacks(tick); super.onDestroy() }
}
