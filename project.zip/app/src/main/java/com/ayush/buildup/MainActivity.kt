package com.ayush.buildup
import android.app.Activity
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.*
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*

class RingView(c: Context, private val sw: Float) : View(c) {
    var frac = 0f
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = sw; color = Color.parseColor("#2A232D") }
    private val fg = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = sw; color = Color.parseColor("#FF6B81"); strokeCap = Paint.Cap.ROUND }
    override fun onDraw(cv: Canvas) {
        val r = RectF(sw, sw, width - sw, height - sw)
        cv.drawArc(r, 0f, 360f, false, bg); cv.drawArc(r, -90f, 360f * frac, false, fg)
    }
}

class MainActivity : Activity() {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var body: LinearLayout
    private lateinit var nav: LinearLayout
    private var started = false; private var tab = 0; private var profile = false
    private var focusSid = 0; private var adding = false; private var schedWeek = false; private var selDay = P.todayIdx()
    private var fName = ""; private var fDays = BooleanArray(7); private var fSh = 7; private var fSm = 0; private var fEh = 8; private var fEm = 0
    private var fAlarm = true; private var fRepeat = true; private val fBreaks = mutableListOf<Int>(); private var etName: EditText? = null
    private val DN = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
    private val BG = Color.parseColor("#18141A"); private val CARD = Color.parseColor("#241E26")
    private val PINK = Color.parseColor("#FF6B81"); private val ORANGE = Color.parseColor("#F97316")
    private val tick = Runnable { render() }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun lp(w: Int, hh: Int, top: Int = 0, wt: Float = 0f) = LinearLayout.LayoutParams(w, hh, wt).apply { topMargin = dp(top) }
    private fun rect(c: Int, r: Int) = GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat() }
    private fun tv(t: String, s: Float, c: Int = Color.WHITE, b: Boolean = false) = TextView(this).apply {
        text = t; textSize = s; setTextColor(c); if (b) setTypeface(null, Typeface.BOLD)
    }
    private fun ctr(t: TextView, top: Int = 0) = t.apply { gravity = Gravity.CENTER; layoutParams = lp(-1, -2, top) }
    private fun box(grad: Boolean = false) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(16), dp(18), dp(16))
        background = if (grad) GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(PINK, ORANGE)).apply { cornerRadius = dp(24).toFloat() } else rect(CARD, 24)
        layoutParams = lp(-1, -2, 12)
    }
    private fun row() = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
    private fun btn(t: String, f: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; setTextColor(Color.BLACK); background = rect(Color.parseColor("#FBF1F4"), 40)
        setOnClickListener { f() }; layoutParams = lp(-1, dp(54), 12)
    }
    private fun name() = P.sp(this).getString("name", "Ayush") ?: "Ayush"
    private fun accOn() = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)?.contains(packageName) == true
    private fun adminOn() = (getSystemService(DEVICE_POLICY_SERVICE) as DevicePolicyManager).isAdminActive(ComponentName(this, AdminReceiver::class.java))

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        focusSid = intent.getIntExtra("focus_sid", 0)
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setBackgroundColor(BG)
            addView(ImageView(context).apply { setImageResource(R.mipmap.ic_launcher); layoutParams = lp(dp(150), dp(150)) })
            addView(tv("Build Up", 30f, b = true).apply { setPadding(0, dp(16), 0, 0) })
            addView(tv("Developed by Ayush", 18f, Color.LTGRAY).apply { setPadding(0, dp(8), 0, 0) })
        })
        h.postDelayed({ openMain() }, 2200)
    }
    private fun openMain() {
        started = true
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(36), dp(20), dp(24)) }
        nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setBackgroundColor(Color.parseColor("#120F14")) }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(BG)
            addView(ScrollView(context).apply { addView(body) }, lp(-1, 0, 0, 1f))
            addView(nav, lp(-1, -2))
        })
        Sched.scheduleAll(this)
        render()
        if (focusSid != 0) {
            val sc = Sched.load(this).find { it.id == focusSid }; focusSid = 0
            stopService(Intent(this, AlarmService::class.java))
            if (sc != null && !P.running(this)) { val m = Sched.focusMin(sc); P.sp(this).edit().putInt("dur", m).apply(); start(m) }
        }
    }
    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        val id = intent?.getIntExtra("focus_sid", 0) ?: 0
        if (id == 0) return
        if (!started) { focusSid = id; return }
        val sc = Sched.load(this).find { it.id == id }
        stopService(Intent(this, AlarmService::class.java))
        if (sc != null && !P.running(this)) { val m = Sched.focusMin(sc); P.sp(this).edit().putInt("dur", m).apply(); start(m) }
    }
    override fun onResume() { super.onResume(); if (started) render() }
    override fun onBackPressed() { if (adding) { adding = false; render() } else if (profile && !P.running(this)) { profile = false; render() } else super.onBackPressed() }

    private fun render() {
        h.removeCallbacks(tick); P.roll(this)
        if (adding) etName?.let { fName = it.text.toString() }
        val sp = P.sp(this)
        if (sp.getBoolean("armed", false) && !P.running(this)) {
            if (adminOn()) (getSystemService(DEVICE_POLICY_SERVICE) as DevicePolicyManager).removeActiveAdmin(ComponentName(this, AdminReceiver::class.java))
            sp.edit().putBoolean("armed", false).apply()
        }
        val run = P.running(this)
        body.removeAllViews(); nav.removeAllViews()
        nav.visibility = if (run || profile || adding) View.GONE else View.VISIBLE
        if (!run && !profile && !adding) listOf("Focus", "Schedule", "Blocks App").forEachIndexed { i, t ->
            nav.addView(TextView(this).apply {
                text = t; gravity = Gravity.CENTER; textSize = 13f; setTextColor(if (tab == i) PINK else Color.GRAY)
                setPadding(0, dp(14), 0, dp(14)); setOnClickListener { tab = i; render() }
            }, lp(0, -2, 0, 1f))
        }
        when { run -> running(); profile -> profileScreen(); adding -> form(); tab == 0 -> focus(); tab == 1 -> schedule(); else -> blocks() }
    }
    private fun header(t: String, sub: String) = row().apply {
        addView(tv(name().take(1).uppercase(), 18f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER; background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(CARD) }
            setOnClickListener { profile = true; render() }
        }, lp(dp(46), dp(46)))
        addView(LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0)
            addView(tv(t, 24f, b = true)); addView(tv(sub, 12f, Color.GRAY))
        }, lp(0, -2, 0, 1f))
        addView(tv("${P.sp(context).getInt("streak", 0)} day streak", 12f, PINK).apply { setPadding(dp(12), dp(6), dp(12), dp(6)); background = rect(CARD, 20) })
    }

    private fun focus() {
        val sp = P.sp(this); val goal = sp.getInt("goal", 2) * 60; val m = sp.getInt("todayMin", 0)
        body.addView(header("Build Up", "Keep your streak alive"))
        body.addView(box(true).apply {
            addView(tv("Today", 14f, Color.BLACK)); addView(tv("${m / 60}h ${m % 60}m", 46f, Color.BLACK, true))
            addView(tv(if (m >= goal) "Daily goal reached 🎉" else "${goal - m} min left to hit your ${goal / 60}h goal", 14f, Color.BLACK))
        })
        val w = P.week(this); val mx = maxOf(1, w.maxOrNull() ?: 1); val t = P.todayIdx()
        body.addView(box().apply {
            addView(tv("This week", 15f, b = true))
            addView(LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.BOTTOM
                for (i in 0..6) addView(LinearLayout(context).apply {
                    orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
                    addView(View(context).apply { background = rect(if (i == t) PINK else Color.parseColor("#3A323D"), 8) }, lp(dp(26), dp(8 + 90 * w[i] / mx), 0))
                    addView(tv("MTWTFSS"[i].toString(), 12f, Color.GRAY).apply { setPadding(0, dp(6), 0, 0) })
                }, lp(0, -2, 0, 1f))
            }, lp(-1, dp(130), 10))
        })
        val et = EditText(this).apply {
            setText(sp.getInt("dur", 30).toString()); inputType = InputType.TYPE_CLASS_NUMBER
            setTextColor(Color.WHITE); textSize = 28f; gravity = Gravity.CENTER
        }
        body.addView(ctr(tv("Focus minutes", 14f, Color.GRAY), 20)); body.addView(et)
        body.addView(btn("▶  Start focus timer") { start(et.text.toString().toIntOrNull() ?: 0) })
    }
    private fun fmt(h: Int, m: Int) = "%d:%02d %s".format(if (h % 12 == 0) 12 else h % 12, m, if (h < 12) "am" else "pm")
    private fun chip(t: String, on: Boolean, f: () -> Unit) = tv(t, 12f, if (on) Color.BLACK else Color.WHITE, true).apply {
        gravity = Gravity.CENTER; setPadding(0, dp(10), 0, dp(10)); background = rect(if (on) PINK else CARD, 14); setOnClickListener { f() }
    }
    private fun card(s: Sc) = box(true).apply {
        addView(row().apply {
            addView(LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                addView(tv(s.name, 18f, Color.BLACK, true))
                addView(tv("${fmt(s.sh, s.sm)} - ${fmt(s.eh, s.em)}", 14f, Color.BLACK))
                if (s.breaks.isNotEmpty()) addView(tv("${s.breaks.size} break: " + s.breaks.joinToString(", ") { "$it min" }, 12f, Color.BLACK))
            }, lp(0, -2, 0, 1f))
            if (s.alarm) addView(tv("🔔", 18f))
            addView(tv("✕", 18f, Color.BLACK, true).apply {
                setPadding(dp(14), dp(8), dp(4), dp(8))
                setOnClickListener { Sched.save(context, Sched.load(context).filter { it.id != s.id }); render() }
            })
        })
    }
    private fun schedule() {
        val all = Sched.load(this).sortedBy { it.sh * 60 + it.sm }
        body.addView(header("Schedule", "Week plan - same every week"))
        body.addView(row().apply {
            for ((i, t) in listOf("Day", "Week").withIndex()) {
                val on = (i == 1) == schedWeek
                addView(tv(t, 15f, if (on) Color.BLACK else Color.GRAY, true).apply {
                    gravity = Gravity.CENTER; setPadding(0, dp(12), 0, dp(12)); background = rect(if (on) PINK else CARD, 14)
                    setOnClickListener { schedWeek = i == 1; render() }
                }, lp(0, -2, 0, 1f).apply { setMargins(dp(2), 0, dp(2), 0) })
            }
        }.apply { layoutParams = lp(-1, -2, 14) })
        if (!schedWeek) {
            body.addView(row().apply {
                for (i in 0..6) addView(chip(DN[i], i == selDay) { selDay = i; render() }, lp(0, -2, 0, 1f).apply { setMargins(dp(2), 0, dp(2), 0) })
            }.apply { layoutParams = lp(-1, -2, 10) })
            val day = all.filter { selDay in it.days }
            if (day.isEmpty()) body.addView(ctr(tv("${DN[selDay]} ko koi schedule nahi", 14f, Color.GRAY), 30))
            for (s in day) body.addView(card(s))
        } else {
            body.addView(box().apply {
                for (d in 0..6) {
                    val l = all.filter { d in it.days }
                    addView(row().apply {
                        addView(tv(DN[d], 14f, PINK, true), lp(dp(48), -2))
                        addView(tv(if (l.isEmpty()) "-" else l.joinToString("\n") { "${it.name}  ${fmt(it.sh, it.sm)}-${fmt(it.eh, it.em)}" }, 13f,
                            if (l.isEmpty()) Color.GRAY else Color.WHITE), lp(0, -2, 0, 1f))
                    }.apply { setPadding(0, dp(8), 0, dp(8)) })
                }
            })
        }
        body.addView(btn("+ Add schedule") {
            fName = ""; fDays = BooleanArray(7); fSh = 7; fSm = 0; fEh = 8; fEm = 0; fAlarm = true; fRepeat = true; fBreaks.clear(); adding = true; render()
        })
    }
    private fun timeBox(label: String, h: Int, m: Int, f: (Int, Int) -> Unit) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(12), dp(16), dp(12)); background = rect(CARD, 18)
        addView(tv(label, 12f, Color.GRAY)); addView(tv(fmt(h, m), 22f, b = true))
        setOnClickListener { TimePickerDialog(this@MainActivity, { _, hh, mm -> f(hh, mm); render() }, h, m, false).show() }
    }
    private fun form() {
        body.addView(row().apply {
            addView(tv("New schedule", 24f, b = true), lp(0, -2, 0, 1f))
            addView(tv("Cancel", 14f, Color.GRAY).apply { setPadding(dp(14), dp(8), dp(14), dp(8)); background = rect(CARD, 20); setOnClickListener { adding = false; render() } })
        })
        body.addView(tv("Name", 12f, Color.GRAY).apply { setPadding(0, dp(16), 0, dp(4)) })
        etName = EditText(this).apply { setText(fName); hint = "Morning Study"; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY) }
        body.addView(etName)
        body.addView(tv("Days (pick one or more)", 12f, Color.GRAY).apply { setPadding(0, dp(16), 0, dp(6)) })
        body.addView(row().apply {
            for (i in 0..6) addView(chip(DN[i], fDays[i]) { fDays[i] = !fDays[i]; render() }, lp(0, -2, 0, 1f).apply { setMargins(dp(2), 0, dp(2), 0) })
        })
        body.addView(tv("Time", 12f, Color.GRAY).apply { setPadding(0, dp(16), 0, dp(6)) })
        body.addView(row().apply {
            addView(timeBox("Start", fSh, fSm) { hh, mm -> fSh = hh; fSm = mm }, lp(0, -2, 0, 1f).apply { setMargins(0, 0, dp(6), 0) })
            addView(timeBox("End", fEh, fEm) { hh, mm -> fEh = hh; fEm = mm }, lp(0, -2, 0, 1f).apply { setMargins(dp(6), 0, 0, 0) })
        })
        body.addView(box().apply {
            addView(Switch(context).apply { text = "Alarm at start time"; setTextColor(Color.WHITE); isChecked = fAlarm; setOnCheckedChangeListener { _, v -> fAlarm = v } })
            addView(Switch(context).apply { text = "Repeat every week"; setTextColor(Color.WHITE); isChecked = fRepeat; setPadding(0, dp(14), 0, 0); setOnCheckedChangeListener { _, v -> fRepeat = v } })
        })
        body.addView(tv("Breaks (max 4, har break 4-20 min)", 12f, Color.GRAY).apply { setPadding(0, dp(16), 0, dp(4)) })
        fBreaks.forEachIndexed { i, b ->
            body.addView(row().apply {
                addView(tv("Break ${i + 1}: $b min", 15f), lp(0, -2, 0, 1f))
                addView(tv("✕", 18f, PINK).apply { setPadding(dp(14), dp(6), dp(4), dp(6)); setOnClickListener { fBreaks.removeAt(i); render() } })
            }.apply { setPadding(dp(14), dp(8), dp(14), dp(8)); background = rect(CARD, 14); layoutParams = lp(-1, -2, 6) })
        }
        if (fBreaks.size < 4) body.addView(btn("+ Add break") {
            val np = NumberPicker(this).apply { minValue = 4; maxValue = 20; value = 10 }
            AlertDialog.Builder(this).setTitle("Break kitne minute ka?").setView(np)
                .setPositiveButton("Add") { _, _ -> fBreaks.add(np.value); render() }.show()
        })
        body.addView(btn("Save schedule") { saveForm() })
    }
    private fun saveForm() {
        etName?.let { fName = it.text.toString() }
        val days = (0..6).filter { fDays[it] }; val st = fSh * 60 + fSm; val en = fEh * 60 + fEm
        val msg = when {
            fName.isBlank() -> "Naam likho"
            days.isEmpty() -> "Kam se kam ek din chuno"
            en <= st -> "End time start ke baad ka hona chahiye"
            fBreaks.size > 4 || fBreaks.any { it < 4 || it > 20 } -> "Break 4 se 20 min ka, aur max 4 hona chahiye"
            fBreaks.sum() >= en - st -> "Breaks ka total schedule se chhota hona chahiye"
            else -> null
        }
        if (msg != null) { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show(); return }
        val l = Sched.load(this)
        l.add(Sc((System.currentTimeMillis() % 90000).toInt() + 1, fName.trim(), days, fSh, fSm, fEh, fEm, fAlarm, fRepeat, fBreaks.toList()))
        Sched.save(this, l); adding = false; render()
    }
    private fun chosen(): List<Pair<String, String>> {
        val pm = packageManager
        return (P.sp(this).getStringSet("apps", emptySet()) ?: emptySet()).mapNotNull {
            try { pm.getApplicationInfo(it, 0).loadLabel(pm).toString() to it } catch (e: Exception) { null }
        }.sortedBy { it.first.lowercase() }
    }
    private fun saveApps(pk: Set<String>) {
        val pm = packageManager
        val labels = pk.mapNotNull { try { pm.getApplicationInfo(it, 0).loadLabel(pm).toString() } catch (e: Exception) { null } }.toSet()
        P.sp(this).edit().putStringSet("apps", pk).putStringSet("labels", labels).apply()
    }
    private fun blocks() {
        val list = chosen()
        body.addView(header("Blocks App", "Apps jo timer mein band rahenge"))
        body.addView(box().apply {
            addView(tv("Blocked apps (${list.size})", 16f, b = true))
            for ((label, pkg) in list) addView(row().apply {
                addView(tv(label, 16f), lp(0, -2, 0, 1f))
                addView(tv("✕", 18f, PINK).apply {
                    setPadding(dp(14), dp(12), dp(4), dp(12))
                    setOnClickListener { saveApps(chosen().map { it.second }.toSet() - pkg); render() }
                })
            })
            if (list.isEmpty()) addView(tv("Abhi koi app nahi chuna.", 14f, Color.GRAY))
        })
        body.addView(btn("+ Add app") { pickApps() })
    }
    private fun pickApps() {
        val pm = packageManager
        val list = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
            .filter { it.second != packageName }.distinctBy { it.second }.sortedBy { it.first.lowercase() }
        val sel = chosen().map { it.second }.toSet()
        val checked = BooleanArray(list.size) { list[it].second in sel }
        AlertDialog.Builder(this).setTitle("Block karne wale apps")
            .setMultiChoiceItems(list.map { it.first }.toTypedArray(), checked) { _, i, v -> checked[i] = v }
            .setPositiveButton("Save") { _, _ -> saveApps(list.indices.filter { checked[it] }.map { list[it].second }.toSet()); render() }.show()
    }
    private fun stat(v: String, l: String) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(0, dp(14), 0, dp(14)); background = rect(CARD, 18)
        addView(tv(v, 20f, b = true)); addView(tv(l, 12f, Color.GRAY))
    }
    private fun profileScreen() {
        val sp = P.sp(this)
        body.addView(row().apply {
            addView(tv("‹", 32f).apply { setPadding(0, 0, dp(16), 0); setOnClickListener { profile = false; render() } })
            addView(tv("Profile", 24f, b = true))
        })
        body.addView(tv(name().take(1).uppercase(), 40f, Color.BLACK, true).apply {
            gravity = Gravity.CENTER
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(PINK, ORANGE)).apply { shape = GradientDrawable.OVAL }
            layoutParams = lp(dp(96), dp(96), 16).apply { gravity = Gravity.CENTER_HORIZONTAL }
        })
        val et = EditText(this).apply { setText(name()); setTextColor(Color.WHITE); textSize = 20f; gravity = Gravity.CENTER }
        body.addView(et)
        body.addView(btn("Save name") { sp.edit().putString("name", et.text.toString().trim().ifEmpty { "Ayush" }).apply(); render() })
        body.addView(row().apply {
            addView(stat("${sp.getInt("streak", 0)}", "Day streak"), lp(0, -2, 0, 1f))
            addView(stat("${sp.getInt("totalMin", 0) / 60} h", "Total focus"), lp(0, -2, 0, 1f).apply { setMargins(dp(8), 0, dp(8), 0) })
            addView(stat("${sp.getInt("goal", 2)} h", "Daily goal"), lp(0, -2, 0, 1f))
        }.apply { layoutParams = lp(-1, -2, 16) })
        body.addView(tv("Daily focus goal", 14f, Color.GRAY).apply { setPadding(0, dp(18), 0, dp(6)) })
        body.addView(row().apply {
            for (g in 1..4) addView(tv("$g h", 16f, if (sp.getInt("goal", 2) == g) Color.BLACK else Color.WHITE, true).apply {
                gravity = Gravity.CENTER; setPadding(0, dp(12), 0, dp(12))
                background = rect(if (sp.getInt("goal", 2) == g) PINK else CARD, 14)
                setOnClickListener { sp.edit().putInt("goal", g).apply(); render() }
            }, lp(0, -2, 0, 1f).apply { setMargins(dp(4), 0, dp(4), 0) })
        })
        body.addView(tv("Settings", 20f, b = true).apply { setPadding(0, dp(24), 0, 0) })
        body.addView(box().apply {
            addView(tv("Accessibility service: " + if (accOn()) "ON ✓" else "OFF ✗", 15f))
            addView(btn("Open Accessibility settings") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
            addView(btn("Test alarm (10 sec baad)") { Sched.test(this@MainActivity); Toast.makeText(this@MainActivity, "10 second mein alarm bajega", Toast.LENGTH_LONG).show() })
            addView(Switch(context).apply {
                text = "Block adult words (timer ke dauran)"; setTextColor(Color.WHITE); isChecked = sp.getBoolean("web", true)
                setPadding(0, dp(14), 0, 0); setOnCheckedChangeListener { _, v -> sp.edit().putBoolean("web", v).apply() }
            })
            addView(tv("Uninstall protection: timer ke saath apne aap ON/OFF", 13f, Color.GRAY).apply { setPadding(0, dp(14), 0, 0) })
        })
    }
    private fun running() {
        val sp = P.sp(this); val tot = sp.getInt("dur", 1) * 60L
        val left = maxOf(0L, (sp.getLong("end", 0) - System.currentTimeMillis()) / 1000)
        body.addView(ctr(tv("FOCUS SESSION", 13f, PINK), 24))
        body.addView(ctr(tv("Stay focused, ${name()}", 22f, b = true), 4))
        body.addView(FrameLayout(this).apply {
            addView(RingView(context, dp(18).toFloat()).apply { frac = 1f - left.toFloat() / tot }, FrameLayout.LayoutParams(dp(260), dp(260), Gravity.CENTER))
            addView(tv("%02d:%02d".format(left / 60, left % 60), 52f, b = true), FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        }, lp(-1, dp(290), 20))
        val apps = chosen()
        body.addView(box().apply {
            addView(tv("${apps.size} apps blocked", 16f, b = true))
            if (apps.isNotEmpty()) addView(tv(apps.joinToString(", ") { it.first }, 13f, Color.LTGRAY))
            addView(tv("Timer khatam hone tak ye band nahi hoga.", 12f, Color.GRAY).apply { setPadding(0, dp(8), 0, 0) })
        })
        h.postDelayed(tick, 1000)
    }
    private fun start(min: Int) {
        if (min !in 1..300) { Toast.makeText(this, "1 se 300 minute daalo", Toast.LENGTH_SHORT).show(); return }
        if (!accOn()) {
            AlertDialog.Builder(this).setMessage("Pehle Accessibility service ON karo: Profile → Settings mein jaao, ya list mein Build Up dhundo.")
                .setPositiveButton("Open") { _, _ -> startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }.show()
            return
        }
        if (!adminOn()) {
            Toast.makeText(this, "Activate dabao, phir wapas aake Start dabao", Toast.LENGTH_LONG).show()
            startActivity(Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, ComponentName(this, AdminReceiver::class.java))
                .putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Timer chalte waqt Build Up uninstall nahi hoga"))
            return
        }
        P.sp(this).edit().putBoolean("armed", true).putInt("dur", min).putLong("end", System.currentTimeMillis() + min * 60000L).apply()
        startForegroundService(Intent(this, TimerService::class.java)); render()
    }
}
