package com.ayush.buildup
import android.app.Activity
import android.app.AlertDialog
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.*
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var root: LinearLayout
    private var started = false
    private val BG = Color.parseColor("#18141A"); private val CARD = Color.parseColor("#241E26"); private val PINK = Color.parseColor("#FF6B81")
    private val tick = Runnable { render() }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun tv(t: String, s: Float, c: Int = Color.WHITE, b: Boolean = false) = TextView(this).apply {
        text = t; textSize = s; setTextColor(c); if (b) setTypeface(null, Typeface.BOLD)
    }
    private fun box(color: Int = CARD) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(16), dp(18), dp(16))
        background = GradientDrawable().apply { setColor(color); cornerRadius = dp(24).toFloat() }
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) }
    }
    private fun btn(t: String, f: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; setTextColor(Color.BLACK)
        background = GradientDrawable().apply { setColor(Color.parseColor("#FBF1F4")); cornerRadius = dp(40).toFloat() }
        setOnClickListener { f() }
        layoutParams = LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(12) }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val s = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setBackgroundColor(BG)
            addView(ImageView(context).apply { setImageResource(R.mipmap.ic_launcher); layoutParams = LinearLayout.LayoutParams(dp(150), dp(150)) })
            addView(tv("Build Up", 30f, b = true).apply { setPadding(0, dp(16), 0, 0) })
            addView(tv("Developed by Ayush", 18f, Color.LTGRAY).apply { setPadding(0, dp(8), 0, 0) })
        }
        setContentView(s)
        h.postDelayed({ openMain() }, 2200)
    }
    private fun openMain() {
        started = true
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(40), dp(20), dp(30)) }
        setContentView(ScrollView(this).apply { setBackgroundColor(BG); addView(root) })
        render()
    }
    override fun onResume() { super.onResume(); if (started) render() }

    private fun accOn() = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)?.contains(packageName) == true
    private fun adminOn() = (getSystemService(DEVICE_POLICY_SERVICE) as DevicePolicyManager).isAdminActive(ComponentName(this, AdminReceiver::class.java))

    private fun render() {
        h.removeCallbacks(tick)
        P.roll(this)
        val sp = P.sp(this); val run = P.running(this)
        root.removeAllViews()
        root.addView(tv("Build Up", 30f, b = true))
        root.addView(tv("${sp.getInt("streak", 0)} day streak", 14f, PINK))
        val m = sp.getInt("todayMin", 0)
        root.addView(box(PINK).apply {
            addView(tv("Today", 14f, Color.BLACK)); addView(tv("${m / 60}h ${m % 60}m", 44f, Color.BLACK, true))
            addView(tv("Daily goal: 2h", 14f, Color.BLACK))
        })
        val n = sp.getStringSet("apps", emptySet())?.size ?: 0
        if (run) {
            val left = (sp.getLong("end", 0) - System.currentTimeMillis()) / 1000
            root.addView(tv("FOCUS SESSION", 13f, PINK).apply { setPadding(0, dp(28), 0, 0); gravity = Gravity.CENTER })
            root.addView(tv("%02d:%02d".format(left / 60, left % 60), 64f, b = true).apply { gravity = Gravity.CENTER })
            root.addView(box().apply {
                addView(tv("$n apps blocked", 16f, b = true))
                addView(tv("Timer khatam hone tak ye band nahi hoga. Settings bhi locked hain.", 13f, Color.GRAY))
            })
            h.postDelayed(tick, 1000)
            return
        }
        val et = EditText(this).apply {
            setText(sp.getInt("dur", 30).toString()); inputType = InputType.TYPE_CLASS_NUMBER
            setTextColor(Color.WHITE); textSize = 28f; gravity = Gravity.CENTER
        }
        root.addView(tv("Focus minutes", 14f, Color.GRAY).apply { setPadding(0, dp(24), 0, 0) })
        root.addView(et)
        root.addView(btn("▶  Start focus timer") { start(et.text.toString().toIntOrNull() ?: 0) })
        root.addView(tv("Settings", 20f, b = true).apply { setPadding(0, dp(28), 0, 0) })
        root.addView(box().apply {
            addView(tv("Accessibility service: " + if (accOn()) "ON ✓" else "OFF ✗", 15f))
            addView(btn("Open Accessibility settings") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
            addView(tv("Uninstall protection: " + if (adminOn()) "ON ✓" else "OFF ✗", 15f).apply { setPadding(0, dp(14), 0, 0) })
            addView(btn("Turn on uninstall protection") {
                startActivity(Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                    .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, ComponentName(this@MainActivity, AdminReceiver::class.java))
                    .putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Timer chalte waqt Build Up uninstall nahi hoga"))
            })
            addView(btn("Choose apps to block ($n)") { pickApps() })
            addView(Switch(context).apply {
                text = "Block adult words in browser"; setTextColor(Color.WHITE); isChecked = sp.getBoolean("web", true)
                setPadding(0, dp(14), 0, 0)
                setOnCheckedChangeListener { _, v -> sp.edit().putBoolean("web", v).apply() }
            })
        })
    }
    private fun start(min: Int) {
        if (min !in 1..300) { Toast.makeText(this, "1 se 300 minute daalo", Toast.LENGTH_SHORT).show(); return }
        if (!accOn()) {
            AlertDialog.Builder(this).setMessage("Pehle Accessibility service ON karo: list mein Build Up dhundo aur ON karo.")
                .setPositiveButton("Open") { _, _ -> startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }.show()
            return
        }
        P.sp(this).edit().putInt("dur", min).putLong("end", System.currentTimeMillis() + min * 60000L).apply()
        startForegroundService(Intent(this, TimerService::class.java))
        render()
    }
    private fun pickApps() {
        val pm = packageManager
        val list = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
            .filter { it.second != packageName }.distinctBy { it.second }.sortedBy { it.first.lowercase() }
        val sel = P.sp(this).getStringSet("apps", emptySet()) ?: emptySet()
        val checked = BooleanArray(list.size) { list[it].second in sel }
        AlertDialog.Builder(this).setTitle("Block karne wale apps")
            .setMultiChoiceItems(list.map { it.first }.toTypedArray(), checked) { _, i, v -> checked[i] = v }
            .setPositiveButton("Save") { _, _ ->
                val s = list.indices.filter { checked[it] }
                P.sp(this).edit().putStringSet("apps", s.map { list[it].second }.toSet())
                    .putStringSet("labels", s.map { list[it].first }.toSet()).apply()
                render()
            }.show()
    }
}
