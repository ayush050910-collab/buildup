package com.ayush.buildup
import android.app.*
import android.content.*
import android.media.AudioAttributes
import android.media.RingtoneManager
import org.json.JSONArray
import org.json.JSONObject
import java.util.*

class Sc(val id: Int, val name: String, val days: List<Int>, val sh: Int, val sm: Int, val eh: Int, val em: Int,
         val alarm: Boolean, val repeat: Boolean, val breaks: List<Int>)

object Sched {
    private fun ints(a: JSONArray) = (0 until a.length()).map { a.getInt(it) }
    fun load(c: Context): MutableList<Sc> {
        val out = mutableListOf<Sc>()
        try {
            val a = JSONArray(P.sp(c).getString("sched", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(Sc(o.getInt("id"), o.getString("name"), ints(o.getJSONArray("days")), o.getInt("sh"), o.getInt("sm"),
                    o.getInt("eh"), o.getInt("em"), o.getBoolean("alarm"), o.getBoolean("repeat"), ints(o.getJSONArray("breaks"))))
            }
        } catch (e: Exception) {}
        return out
    }
    fun save(c: Context, l: List<Sc>) {
        val a = JSONArray()
        for (s in l) a.put(JSONObject().put("id", s.id).put("name", s.name).put("days", JSONArray(s.days))
            .put("sh", s.sh).put("sm", s.sm).put("eh", s.eh).put("em", s.em)
            .put("alarm", s.alarm).put("repeat", s.repeat).put("breaks", JSONArray(s.breaks)))
        P.sp(c).edit().putString("sched", a.toString()).apply()
        scheduleAll(c)
    }
    private fun pi(c: Context, rc: Int) = PendingIntent.getBroadcast(c, rc,
        Intent(c, AlarmReceiver::class.java).putExtra("rc", rc), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    fun focusMin(s: Sc): Int {
        val st = s.sh * 60 + s.sm; val en = s.eh * 60 + s.em
        val n = Calendar.getInstance(); val now = n.get(Calendar.HOUR_OF_DAY) * 60 + n.get(Calendar.MINUTE)
        return minOf(300, if (now in st until en) en - now else en - st)
    }
    fun test(c: Context) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val show = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        try { am.setAlarmClock(AlarmManager.AlarmClockInfo(System.currentTimeMillis() + 10000, show), pi(c, -2)) } catch (e: Exception) {}
    }
    fun scheduleAll(c: Context) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val sp = P.sp(c)
        for (rc in sp.getStringSet("rc", emptySet()) ?: emptySet()) am.cancel(pi(c, rc.toInt()))
        val codes = mutableSetOf<String>()
        val show = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        for (s in load(c)) if (s.alarm) for (d in s.days) {
            val cal = Calendar.getInstance()
            cal.set(Calendar.DAY_OF_WEEK, (d + 1) % 7 + 1)
            cal.set(Calendar.HOUR_OF_DAY, s.sh); cal.set(Calendar.MINUTE, s.sm); cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
            if (cal.timeInMillis <= System.currentTimeMillis()) cal.add(Calendar.DAY_OF_YEAR, 7)
            val rc = s.id * 10 + d
            try { am.setAlarmClock(AlarmManager.AlarmClockInfo(cal.timeInMillis, show), pi(c, rc)) } catch (e: Exception) {}
            codes.add(rc.toString())
        }
        sp.edit().putStringSet("rc", codes).apply()
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) { Sched.scheduleAll(c) }
}
