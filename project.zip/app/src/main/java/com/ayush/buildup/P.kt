package com.ayush.buildup
import android.content.Context
import android.content.SharedPreferences
import java.text.SimpleDateFormat
import java.util.*

object P {
    fun sp(c: Context): SharedPreferences = c.getSharedPreferences("bu", 0)
    fun running(c: Context) = sp(c).getLong("end", 0) > System.currentTimeMillis()
    private fun day(off: Int = 0): String {
        val cal = Calendar.getInstance(); cal.add(Calendar.DAY_OF_YEAR, off)
        return SimpleDateFormat("yyyyMMdd", Locale.US).format(cal.time)
    }
    fun roll(c: Context) {
        val s = sp(c); val e = s.edit()
        if (s.getString("day", "") != day()) e.putString("day", day()).putInt("todayMin", 0)
        val l = s.getString("last", "")
        if (l != day() && l != day(-1)) e.putInt("streak", 0)
        e.apply()
    }
    fun complete(c: Context) {
        roll(c); val s = sp(c); val e = s.edit()
        if (s.getString("last", "") != day()) { e.putInt("streak", s.getInt("streak", 0) + 1); e.putString("last", day()) }
        e.putInt("todayMin", s.getInt("todayMin", 0) + s.getInt("dur", 0)).putLong("end", 0).apply()
    }
}
