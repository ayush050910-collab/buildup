package com.ayush.buildup
import android.app.admin.DeviceAdminReceiver
class AdminReceiver : DeviceAdminReceiver()
