plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.ayush.buildup"
    compileSdk = 34
    defaultConfig { applicationId = "com.ayush.buildup"; minSdk = 26; targetSdk = 34; versionCode = 4; versionName = "1.3" }
    signingConfigs {
        create("fixed") {
            storeFile = file("buildup.keystore"); storeType = "pkcs12"
            storePassword = "buildup123"; keyAlias = "buildup"; keyPassword = "buildup123"
        }
    }
    buildTypes { getByName("debug") { signingConfig = signingConfigs.getByName("fixed") } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
